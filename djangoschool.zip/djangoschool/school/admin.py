from django.contrib import admin
from .models import ExamScore
# Register your models here.

admin.site.register(ExamScore)
